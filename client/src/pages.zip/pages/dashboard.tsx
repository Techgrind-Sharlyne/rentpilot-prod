import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  DollarSign, 
  Home, 
  Clock, 
  Wrench, 
  TrendingUp,
  AlertTriangle 
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { DashboardStatsResponse, RecentPaymentsResponse, MaintenanceRequestsResponse } from "@/types/api";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStatsResponse>({
    queryKey: ["/api/dashboard/stats"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/dashboard/stats");
      return await response.json();
    },
  });

  const { data: recentPayments, isLoading: paymentsLoading } = useQuery<RecentPaymentsResponse>({
    queryKey: ["/api/dashboard/recent-payments"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/dashboard/recent-payments");
      return await response.json();
    },
  });

  const { data: maintenanceRequests, isLoading: maintenanceLoading } = useQuery<MaintenanceRequestsResponse>({
    queryKey: ["/api/maintenance-requests"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/maintenance-requests");
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
  });

  const formatCurrency = (amount: number) => 
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount);

  const formatDate = (date: string) =>
    new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(new Date(date));

  const getStatusColor = (status: string) => {
    switch (status) {
      case "paid": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
      case "pending": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
      case "overdue": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300";
      case "urgent": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300";
      case "high": return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300";
      case "normal": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
      case "low": return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300";
    }
  };

  const urgentMaintenance = maintenanceRequests?.filter(
    (req: any) => req.priority === "urgent" && req.status !== "completed"
  ) || [];

  return (
    <>
      <Header 
        title="Dashboard" 
        subtitle="Welcome back! Here's your property overview"
      />
      
      <div className="p-6 space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card data-testid="total-revenue-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-muted-foreground">Total Revenue</h3>
                <DollarSign className="h-5 w-5 text-green-500" />
              </div>
              {statsLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <div className="text-2xl font-bold" data-testid="total-revenue-value">
                  {formatCurrency(stats?.totalRevenue || 0)}
                </div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                <span className="text-green-500">↗ Monthly rent collection</span>
              </p>
            </CardContent>
          </Card>
          
          <Card data-testid="occupied-units-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-muted-foreground">Occupied Units</h3>
                <Home className="h-5 w-5 text-blue-500" />
              </div>
              {statsLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold" data-testid="occupied-units-value">
                  {stats?.occupiedUnits || 0}/{stats?.totalUnits || 0}
                </div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                {stats?.totalUnits > 0 
                  ? `${((stats.occupiedUnits / stats.totalUnits) * 100).toFixed(1)}% occupancy rate`
                  : "No units available"
                }
              </p>
            </CardContent>
          </Card>
          
          <Card data-testid="pending-payments-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-muted-foreground">Pending Payments</h3>
                <Clock className="h-5 w-5 text-amber-500" />
              </div>
              {statsLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <div className="text-2xl font-bold" data-testid="pending-payments-value">
                  {formatCurrency(stats?.pendingPayments || 0)}
                </div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                {stats?.overdueCount || 0} overdue payments
              </p>
            </CardContent>
          </Card>
          
          <Card data-testid="maintenance-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-muted-foreground">Maintenance</h3>
                <Wrench className="h-5 w-5 text-red-500" />
              </div>
              {statsLoading ? (
                <Skeleton className="h-8 w-12" />
              ) : (
                <div className="text-2xl font-bold" data-testid="maintenance-count-value">
                  {stats?.maintenanceCount || 0}
                </div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                {stats?.urgentMaintenanceCount || 0} urgent requests
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row - Placeholder for future chart implementation */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-72 bg-muted rounded-lg flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <TrendingUp className="h-12 w-12 mx-auto mb-2" />
                  <p className="text-lg font-medium">Chart Coming Soon</p>
                  <p className="text-sm">Revenue analytics will be displayed here</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Occupancy Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-72 bg-muted rounded-lg flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <Home className="h-12 w-12 mx-auto mb-2" />
                  <p className="text-lg font-medium">Chart Coming Soon</p>
                  <p className="text-sm">Occupancy trends will be displayed here</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activities */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Payments */}
          <Card data-testid="recent-payments-card">
            <CardHeader>
              <CardTitle>Recent Payments</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {paymentsLoading ? (
                <>
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </>
              ) : recentPayments?.length > 0 ? (
                recentPayments.map((payment: any) => (
                  <div
                    key={payment.id}
                    className="flex items-center justify-between py-2 border-b border-border last:border-b-0"
                    data-testid={`payment-${payment.id}`}
                  >
                    <div>
                      <p className="font-medium text-sm">
                        {payment.tenant?.firstName} {payment.tenant?.lastName}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {payment.unit?.unitNumber} - {payment.property?.name}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-sm text-green-600">
                        {formatCurrency(Number(payment.amount))}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatDate(payment.paymentDate)}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No recent payments</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Urgent Maintenance */}
          <Card data-testid="urgent-maintenance-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                Urgent Maintenance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {maintenanceLoading ? (
                <>
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
                </>
              ) : urgentMaintenance.length > 0 ? (
                urgentMaintenance.slice(0, 3).map((request: any) => (
                  <div
                    key={request.id}
                    className="flex items-start space-x-3 py-2"
                    data-testid={`urgent-maintenance-${request.id}`}
                  >
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{request.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {request.unit?.unitNumber} - {request.property?.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Created {formatDate(request.createdAt)}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No urgent maintenance requests</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card data-testid="quick-stats-card">
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Collection Rate</span>
                <div className="flex items-center space-x-2">
                  <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                    <div className="w-4/5 h-full bg-green-500"></div>
                  </div>
                  <span className="text-sm font-medium">94%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Avg Response Time</span>
                <span className="text-sm font-medium">2.4 hrs</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Tenant Satisfaction</span>
                <span className="text-sm font-medium">4.6/5</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
