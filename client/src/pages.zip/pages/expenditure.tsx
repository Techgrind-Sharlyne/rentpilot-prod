import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Plus, DollarSign, TrendingDown, Calendar, Building, 
  Users, Wrench, Shield, Car, Trash2, Edit, Search, Filter
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import type { PropertyWithDetails } from "@shared/schema";

interface Expenditure {
  id: string;
  propertyId?: string;
  category: 'caretaker' | 'security' | 'maintenance' | 'utilities' | 'management' | 'other';
  amount: number;
  description: string;
  paymentDate: string;
  recipient: string;
  paymentMethod: string;
  recurring: boolean;
  recurringPeriod?: 'monthly' | 'quarterly' | 'yearly';
  nextDueDate?: string;
}

const expenditureFormSchema = z.object({
  propertyId: z.string().optional(),
  category: z.enum(['caretaker', 'security', 'maintenance', 'utilities', 'management', 'other']),
  amount: z.number().min(1, "Amount is required"),
  description: z.string().min(1, "Description is required"),
  paymentDate: z.string().min(1, "Payment date is required"),
  recipient: z.string().min(1, "Recipient is required"),
  paymentMethod: z.string().min(1, "Payment method is required"),
  recurring: z.boolean().default(false),
  recurringPeriod: z.enum(['monthly', 'quarterly', 'yearly']).optional(),
  nextDueDate: z.string().optional(),
});

type ExpenditureFormData = z.infer<typeof expenditureFormSchema>;

export default function Expenditure() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expenditure | null>(null);

  // Fetch properties
  const { data: properties, isLoading: propertiesLoading } = useQuery<PropertyWithDetails[]>({
    queryKey: ["/api/properties"],
  });

  // Mock expenditure data - will be replaced with real backend data
  const mockExpenditures: Expenditure[] = useMemo(() => [
    {
      id: "exp-1",
      propertyId: properties?.[0]?.id,
      category: "caretaker",
      amount: 25000,
      description: "Monthly caretaker salary",
      paymentDate: "2025-01-15",
      recipient: "John Mburu",
      paymentMethod: "bank_transfer",
      recurring: true,
      recurringPeriod: "monthly",
      nextDueDate: "2025-02-15"
    },
    {
      id: "exp-2",
      propertyId: properties?.[0]?.id,
      category: "security",
      amount: 30000,
      description: "Security guard wages",
      paymentDate: "2025-01-20",
      recipient: "SecureGuard Services",
      paymentMethod: "mpesa",
      recurring: true,
      recurringPeriod: "monthly",
      nextDueDate: "2025-02-20"
    },
    {
      id: "exp-3",
      category: "management",
      amount: 15000,
      description: "Property management software subscription",
      paymentDate: "2025-01-10",
      recipient: "PropTech Solutions",
      paymentMethod: "credit_card",
      recurring: true,
      recurringPeriod: "monthly",
      nextDueDate: "2025-02-10"
    },
    {
      id: "exp-4",
      propertyId: properties?.[1]?.id,
      category: "maintenance",
      amount: 8500,
      description: "Plumbing repairs - Unit 2A",
      paymentDate: "2025-01-25",
      recipient: "Fix-It Plumbers",
      paymentMethod: "cash",
      recurring: false
    },
    {
      id: "exp-5",
      category: "other",
      amount: 5000,
      description: "Legal consultation fees",
      paymentDate: "2025-01-12",
      recipient: "Kamau & Associates",
      paymentMethod: "bank_transfer",
      recurring: false
    }
  ], [properties]);

  // Filter expenditures
  const filteredExpenditures = useMemo(() => {
    return mockExpenditures.filter((expense) => {
      // Property filter
      if (selectedPropertyId === "property") {
        if (!expense.propertyId) return false;
      } else if (selectedPropertyId === "general") {
        if (expense.propertyId) return false;
      } else if (selectedPropertyId !== "all") {
        if (expense.propertyId !== selectedPropertyId) return false;
      }

      // Category filter
      if (selectedCategory !== "all" && expense.category !== selectedCategory) {
        return false;
      }

      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        return (
          expense.description.toLowerCase().includes(searchLower) ||
          expense.recipient.toLowerCase().includes(searchLower)
        );
      }

      return true;
    });
  }, [mockExpenditures, selectedPropertyId, selectedCategory, searchTerm]);

  // Calculate analytics
  const analytics = useMemo(() => {
    const totalExpenditure = filteredExpenditures.reduce((sum, exp) => sum + exp.amount, 0);
    const propertySpecific = filteredExpenditures.filter(exp => exp.propertyId).reduce((sum, exp) => sum + exp.amount, 0);
    const generalExpenses = filteredExpenditures.filter(exp => !exp.propertyId).reduce((sum, exp) => sum + exp.amount, 0);
    const recurringExpenses = filteredExpenditures.filter(exp => exp.recurring).reduce((sum, exp) => sum + exp.amount, 0);
    const oneTimeExpenses = filteredExpenditures.filter(exp => !exp.recurring).reduce((sum, exp) => sum + exp.amount, 0);
    
    const categoryBreakdown = filteredExpenditures.reduce((acc, exp) => {
      acc[exp.category] = (acc[exp.category] || 0) + exp.amount;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalExpenditure,
      propertySpecific,
      generalExpenses,
      recurringExpenses,
      oneTimeExpenses,
      categoryBreakdown,
      expenseCount: filteredExpenditures.length
    };
  }, [filteredExpenditures]);

  // Form setup
  const form = useForm<ExpenditureFormData>({
    resolver: zodResolver(expenditureFormSchema),
    defaultValues: {
      amount: 0,
      recurring: false,
      paymentDate: new Date().toISOString().split('T')[0],
    }
  });

  // Create/Update expenditure mutation
  const expenditureMutation = useMutation({
    mutationFn: async (data: ExpenditureFormData) => {
      const endpoint = editingExpense ? `/api/expenditures/${editingExpense.id}` : "/api/expenditures";
      const method = editingExpense ? "PUT" : "POST";
      return await apiRequest(method, endpoint, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenditures"] });
      toast({
        title: "Success",
        description: `Expenditure ${editingExpense ? 'updated' : 'added'} successfully!`,
      });
      setIsCreating(false);
      setEditingExpense(null);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || `Failed to ${editingExpense ? 'update' : 'create'} expenditure`,
        variant: "destructive",
      });
    },
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      caretaker: Users,
      security: Shield,
      maintenance: Wrench,
      utilities: DollarSign,
      management: Building,
      other: DollarSign,
    };
    const Icon = icons[category as keyof typeof icons] || DollarSign;
    return <Icon className="w-4 h-4" />;
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      caretaker: "bg-blue-100 text-blue-800",
      security: "bg-red-100 text-red-800",
      maintenance: "bg-yellow-100 text-yellow-800",
      utilities: "bg-green-100 text-green-800",
      management: "bg-purple-100 text-purple-800",
      other: "bg-gray-100 text-gray-800",
    };
    return colors[category as keyof typeof colors] || colors.other;
  };

  const onSubmit = (data: ExpenditureFormData) => {
    expenditureMutation.mutate(data);
  };

  if (propertiesLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Expenditure Management</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">Track property expenses, recurring payments, and manage financial outflows</p>
        </div>
        <Dialog open={isCreating || !!editingExpense} onOpenChange={(open) => {
          setIsCreating(open);
          if (!open) {
            setEditingExpense(null);
            form.reset();
          }
        }}>
          <DialogTrigger asChild>
            <Button onClick={() => setIsCreating(true)} className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700" data-testid="button-add-expenditure">
              <Plus className="w-4 h-4 mr-2" />
              Add Expenditure
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingExpense ? 'Edit' : 'Add'} Expenditure</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select onValueChange={(value) => form.setValue("category", value as any)}>
                    <SelectTrigger data-testid="select-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="caretaker">Caretaker</SelectItem>
                      <SelectItem value="security">Security</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="utilities">Utilities</SelectItem>
                      <SelectItem value="management">Management</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="propertyId">Property (Optional)</Label>
                  <Select onValueChange={(value) => form.setValue("propertyId", value === "none" ? undefined : value)}>
                    <SelectTrigger data-testid="select-property">
                      <SelectValue placeholder="General expense" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">General Expense</SelectItem>
                      {properties?.map((property) => (
                        <SelectItem key={property.id} value={property.id}>
                          {property.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="amount">Amount (KES)</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    {...form.register("amount", { valueAsNumber: true })}
                    data-testid="input-amount"
                  />
                </div>

                <div>
                  <Label htmlFor="paymentDate">Payment Date</Label>
                  <Input
                    id="paymentDate"
                    type="date"
                    {...form.register("paymentDate")}
                    data-testid="input-payment-date"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="recipient">Recipient</Label>
                <Input
                  id="recipient"
                  {...form.register("recipient")}
                  placeholder="Enter recipient name"
                  data-testid="input-recipient"
                />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  {...form.register("description")}
                  placeholder="Enter expense description"
                  data-testid="textarea-description"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="paymentMethod">Payment Method</Label>
                  <Select onValueChange={(value) => form.setValue("paymentMethod", value)}>
                    <SelectTrigger data-testid="select-payment-method">
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                      <SelectItem value="mpesa">M-Pesa</SelectItem>
                      <SelectItem value="check">Check</SelectItem>
                      <SelectItem value="credit_card">Credit Card</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="recurringPeriod">Recurring</Label>
                  <Select onValueChange={(value) => {
                    if (value === "none") {
                      form.setValue("recurring", false);
                      form.setValue("recurringPeriod", undefined);
                    } else {
                      form.setValue("recurring", true);
                      form.setValue("recurringPeriod", value as any);
                    }
                  }}>
                    <SelectTrigger data-testid="select-recurring">
                      <SelectValue placeholder="One-time payment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">One-time payment</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center space-x-2 pt-4">
                <Button
                  type="submit"
                  disabled={expenditureMutation.isPending}
                  className="bg-primary hover:bg-primary/90"
                  data-testid="button-save-expenditure"
                >
                  {expenditureMutation.isPending ? "Saving..." : editingExpense ? "Update" : "Add"} Expenditure
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsCreating(false);
                    setEditingExpense(null);
                    form.reset();
                  }}
                  data-testid="button-cancel-expenditure"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Quick Stats Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        <Card className="bg-gradient-to-br from-red-500 to-pink-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm">Total Expenditure</p>
                <p className="text-xl font-bold">{formatCurrency(analytics.totalExpenditure)}</p>
              </div>
              <TrendingDown className="w-8 h-8 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-indigo-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Property Specific</p>
                <p className="text-xl font-bold">{formatCurrency(analytics.propertySpecific)}</p>
              </div>
              <Building className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-emerald-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">General Expenses</p>
                <p className="text-xl font-bold">{formatCurrency(analytics.generalExpenses)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-violet-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Recurring</p>
                <p className="text-xl font-bold">{formatCurrency(analytics.recurringExpenses)}</p>
              </div>
              <Calendar className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-gray-600 to-gray-700 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Total Entries</p>
                <p className="text-xl font-bold">{analytics.expenseCount}</p>
              </div>
              <DollarSign className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Search */}
            <div>
              <label className="text-sm font-medium mb-2 block">Search</label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                <Input
                  placeholder="Search description or recipient..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-expenditure"
                />
              </div>
            </div>

            {/* Property Filter */}
            <div>
              <label className="text-sm font-medium mb-2 block">Property</label>
              <Select value={selectedPropertyId} onValueChange={setSelectedPropertyId}>
                <SelectTrigger data-testid="select-property-filter">
                  <SelectValue placeholder="All Expenses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Expenses</SelectItem>
                  <SelectItem value="property">Property Specific Only</SelectItem>
                  <SelectItem value="general">General Expenses Only</SelectItem>
                  {properties?.map((property) => (
                    <SelectItem key={property.id} value={property.id}>
                      {property.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Category Filter */}
            <div>
              <label className="text-sm font-medium mb-2 block">Category</label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger data-testid="select-category-filter">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="caretaker">Caretaker</SelectItem>
                  <SelectItem value="security">Security</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="utilities">Utilities</SelectItem>
                  <SelectItem value="management">Management</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Reset Filters */}
            <div>
              <label className="text-sm font-medium mb-2 block">&nbsp;</label>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSelectedPropertyId("all");
                  setSelectedCategory("all");
                  setSearchTerm("");
                }}
                className="w-full"
                data-testid="button-reset-filters"
              >
                Reset Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Expenditure List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Expenditures ({filteredExpenditures.length} entries)
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredExpenditures.length === 0 ? (
            <div className="text-center py-12">
              <DollarSign className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No Expenditure Records Found</h3>
              <p className="text-muted-foreground">Start by adding your first expense record.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredExpenditures.map((expense) => {
                const property = properties?.find(p => p.id === expense.propertyId);
                
                return (
                  <div
                    key={expense.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    data-testid={`expenditure-item-${expense.id}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-pink-500 rounded-full flex items-center justify-center text-white">
                        {getCategoryIcon(expense.category)}
                      </div>
                      <div>
                        <h4 className="font-semibold">{expense.description}</h4>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                          <span>To: {expense.recipient}</span>
                          <span>•</span>
                          <span>{expense.paymentDate}</span>
                          {property && (
                            <>
                              <span>•</span>
                              <div className="flex items-center gap-1">
                                <Building className="w-3 h-3" />
                                <span>{property.name}</span>
                              </div>
                            </>
                          )}
                          {expense.recurring && (
                            <>
                              <span>•</span>
                              <Badge variant="outline" className="text-xs">
                                {expense.recurringPeriod}
                              </Badge>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <Badge className={getCategoryColor(expense.category)} data-testid={`category-${expense.category}`}>
                        {expense.category}
                      </Badge>
                      <div className="text-right">
                        <p className="font-semibold text-red-600">{formatCurrency(expense.amount)}</p>
                        <p className="text-sm text-muted-foreground capitalize">
                          {expense.paymentMethod.replace('_', ' ')}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setEditingExpense(expense);
                          // Populate form with expense data
                          Object.entries(expense).forEach(([key, value]) => {
                            if (key in form.getValues()) {
                              form.setValue(key as any, value);
                            }
                          });
                        }}
                        className="h-6 w-6 p-0 hover:bg-blue-100 hover:text-blue-600"
                        data-testid={`button-edit-expenditure-${expense.id}`}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}