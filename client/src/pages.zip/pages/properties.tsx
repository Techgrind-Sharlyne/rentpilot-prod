import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Building, Edit, Home, Eye, DollarSign, Settings, Search, Filter, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLocation } from "wouter";
import type { PropertyWithDetails } from "@shared/schema";
import { AddPropertyModal } from "@/components/modals/add-property-modal";


export default function Properties() {
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const [showAddPropertyModal, setShowAddPropertyModal] = useState(false);
  const [showAddUnitModal, setShowAddUnitModal] = useState(false);
  const [editingProperty, setEditingProperty] = useState<PropertyWithDetails | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOrder, setSortOrder] = useState<"latest" | "oldest">("latest");

  const updatePropertyMutation = useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      return await apiRequest("PUT", `/api/properties/${id}`, { name });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      toast({ title: "Success", description: "Property updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update property", variant: "destructive" });
    },
  });

  const { data: properties, isLoading } = useQuery({
    queryKey: ["/api/properties"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/properties");
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
  });

  // Delete property mutation
  const deletePropertyMutation = useMutation({
    mutationFn: async (propertyId: string) => {
      return await apiRequest("DELETE", `/api/properties/${propertyId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      toast({ title: "Success", description: "Property deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete property", variant: "destructive" });
    },
  });

  // Filter and sort properties
  const filteredAndSortedProperties = properties
    ?.filter(property => {
      const query = searchQuery.toLowerCase();
      return property.name.toLowerCase().includes(query) || 
             property.city.toLowerCase().includes(query) ||
             property.address?.toLowerCase().includes(query) || 
             property.type.toLowerCase().includes(query);
    })
    ?.sort((a, b) => {
      const dateA = new Date(a.createdAt || 0).getTime();
      const dateB = new Date(b.createdAt || 0).getTime();
      return sortOrder === "latest" ? dateB - dateA : dateA - dateB;
    }) || [];

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
    }).format(amount);

  // Calculate analytics from properties data
  const analytics = properties ? {
    totalProperties: properties.length,
    totalUnits: properties.reduce((sum, p) => sum + (p.totalUnits || 0), 0),
    totalOccupied: properties.reduce((sum, p) => sum + (Number(p.occupiedUnits) || 0), 0),
    totalRevenue: properties.reduce((sum, p) => sum + (Number(p.monthlyRevenue) || 0), 0),
    avgOccupancy: properties.length > 0 
      ? properties.reduce((sum, p) => sum + (p.occupancyRate || 0), 0) / properties.length 
      : 0,
    propertyTypes: properties.reduce((acc, p) => {
      acc[p.type] = (acc[p.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
  } : null;

  if (isLoading) {
    return <div className="p-6">Loading properties...</div>;
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6" data-testid="properties-page">
      {/* Header */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Properties Portfolio
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage and monitor your real estate investments
          </p>
        </div>
        <Button 
          onClick={() => setShowAddPropertyModal(true)} 
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-200"
          data-testid="button-add-property"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Property
        </Button>
      </div>

      {/* Analytics Section */}
      {analytics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-600 dark:text-blue-400 font-medium">Total Properties</p>
                  <p className="text-2xl font-bold text-blue-700 dark:text-blue-300">{analytics.totalProperties}</p>
                </div>
                <Building className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-600 dark:text-green-400 font-medium">Monthly Revenue</p>
                  <p className="text-2xl font-bold text-green-700 dark:text-green-300">
                    {formatCurrency(analytics.totalRevenue)}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 border-purple-200 dark:border-purple-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">Total Units</p>
                  <p className="text-2xl font-bold text-purple-700 dark:text-purple-300">
                    {analytics.totalOccupied}/{analytics.totalUnits}
                  </p>
                  <p className="text-xs text-purple-500">Occupied</p>
                </div>
                <Home className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 border-orange-200 dark:border-orange-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-orange-600 dark:text-orange-400 font-medium">Avg Occupancy</p>
                  <p className="text-2xl font-bold text-orange-700 dark:text-orange-300">
                    {Math.round(analytics.avgOccupancy)}%
                  </p>
                </div>
                <Eye className="w-8 h-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}


      {/* Properties List */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Properties ({filteredAndSortedProperties.length} {searchQuery ? `of ${properties?.length || 0}` : ''})</h2>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">View:</span>
            <Button variant="outline" size="sm" className="h-8">Grid</Button>
          </div>
        </div>
        
        {/* Search and Filter Controls */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search properties by name, city, address, or type..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              data-testid="input-search-properties"
            />
          </div>
          <Select value={sortOrder} onValueChange={setSortOrder}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="latest">Latest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredAndSortedProperties.map((property: PropertyWithDetails) => (
            <Card key={property.id} className="group hover:shadow-lg hover:scale-[1.02] transition-all duration-200 border-l-4 border-l-purple-500" data-testid={`property-card-${property.id}`}>
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg leading-tight group-hover:text-purple-600 transition-colors">
                        {property.name}
                      </h3>
                      <p className="text-xs text-muted-foreground capitalize mt-1">
                        {property.type.replace('_', ' ')}
                      </p>
                    </div>
                    <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                      <Building className="w-4 h-4 text-white" />
                    </div>
                  </div>
                  
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {property.address && `${property.address}, `}{property.city}, {property.state}
                  </p>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg">
                      <div className="text-blue-600 dark:text-blue-400 font-medium">Units</div>
                      <div className="font-bold text-blue-700 dark:text-blue-300">
                        {property.occupiedUnits || 0}/{property.totalUnits}
                      </div>
                    </div>
                    <div className="bg-green-50 dark:bg-green-900/20 p-2 rounded-lg">
                      <div className="text-green-600 dark:text-green-400 font-medium">Revenue</div>
                      <div className="font-bold text-green-700 dark:text-green-300 text-xs">
                        {formatCurrency(Number(property.monthlyRevenue || 0))}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center space-x-1">
                      <div className={`w-2 h-2 rounded-full ${
                        (property.occupancyRate || 0) > 80 ? 'bg-green-500' :
                        (property.occupancyRate || 0) > 50 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}></div>
                      <span className="text-xs text-muted-foreground">
                        {property.occupancyRate ? `${Math.round(property.occupancyRate)}%` : '0%'} occupied
                      </span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button 
                        size="sm" 
                        variant="ghost"
                        className="h-6 w-6 p-0 hover:bg-green-100 hover:text-green-600"
                        onClick={() => setShowAddUnitModal(true)}
                        data-testid={`button-manage-property-${property.id}`}
                      >
                        <Settings className="w-3 h-3" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        className="h-6 w-6 p-0 hover:bg-purple-100 hover:text-purple-600"
                        onClick={() => {
                          setEditingProperty(property);
                          setShowAddPropertyModal(true);
                        }}
                        data-testid={`button-update-property-${property.id}`}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        className="h-6 w-6 p-0 hover:bg-red-100 hover:text-red-600"
                        onClick={() => {
                          if (confirm(`Are you sure you want to delete "${property.name}"? This action cannot be undone.`)) {
                            deletePropertyMutation.mutate(property.id);
                          }
                        }}
                        data-testid={`button-delete-property-${property.id}`}
                        disabled={deletePropertyMutation.isPending}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                      <Button 
                        size="sm" 
                        className="h-6 px-2 text-xs bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                        onClick={() => setLocation(`/units?propertyId=${property.id}`)}
                        data-testid={`button-view-units-${property.id}`}
                      >
                        <Home className="w-3 h-3 mr-1" />
                        Units
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {filteredAndSortedProperties.length === 0 && (
        <div className="text-center py-12">
          <Building className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No Properties Found</h3>
          <p className="text-muted-foreground mb-4">Get started by adding your first property.</p>
          <Button onClick={() => setShowAddPropertyModal(true)} className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Property
          </Button>
        </div>
      )}
      
      {/* Add Property Modal */}
      <AddPropertyModal
        open={showAddPropertyModal}
        onClose={() => {
          setShowAddPropertyModal(false);
          setEditingProperty(null);
        }}
        editProperty={editingProperty}
      />
    </div>
  );
}