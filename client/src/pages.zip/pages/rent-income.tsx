import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  DollarSign, TrendingUp, Clock, CheckCircle, 
  AlertCircle, Users, Building, Home, Calendar, Search, Filter, Plus
} from "lucide-react";
import { RentCollectionModal } from "@/components/modals/rent-collection-modal";
import type { TenantWithDetails, PropertyWithDetails, UnitWithDetails } from "@shared/schema";

interface PaymentStatus {
  id: string;
  tenantId: string;
  amount: number;
  dueDate: string;
  status: 'paid' | 'late' | 'pending' | 'prepaid';
  paymentDate?: string;
  method?: string;
}

export default function RentIncome() {
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>("all");
  const [selectedUnitId, setSelectedUnitId] = useState<string>("all");
  const [selectedTenantId, setSelectedTenantId] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [showRentCollectionModal, setShowRentCollectionModal] = useState(false);

  // Fetch data
  const { data: properties, isLoading: propertiesLoading } = useQuery<PropertyWithDetails[]>({
    queryKey: ["/api/properties"],
  });

  const { data: units, isLoading: unitsLoading } = useQuery<UnitWithDetails[]>({
    queryKey: ["/api/units"],
  });

  const { data: tenants, isLoading: tenantsLoading } = useQuery<TenantWithDetails[]>({
    queryKey: ["/api/tenants"],
  });

  // Mock payment data - will be replaced with real data from backend
  const mockPaymentData: PaymentStatus[] = useMemo(() => {
    if (!tenants) return [];
    
    return tenants.map((tenant) => ({
      id: `payment-${tenant.id}`,
      tenantId: tenant.id,
      amount: tenant.monthlyRent || 0,
      dueDate: "2025-02-01",
      status: Math.random() > 0.7 ? 'paid' : Math.random() > 0.5 ? 'pending' : Math.random() > 0.3 ? 'late' : 'prepaid',
      paymentDate: Math.random() > 0.5 ? "2025-01-28" : undefined,
      method: ['bank_transfer', 'mpesa', 'cash'][Math.floor(Math.random() * 3)]
    }));
  }, [tenants]);

  // Filter units based on selected property
  const filteredUnits = useMemo(() => {
    if (!units) return [];
    if (selectedPropertyId === "all") return units;
    return units.filter(unit => unit.propertyId === selectedPropertyId);
  }, [units, selectedPropertyId]);

  // Filter tenants based on selections and search
  const filteredPayments = useMemo(() => {
    if (!mockPaymentData || !tenants) return [];
    
    return mockPaymentData.filter((payment) => {
      const tenant = tenants.find(t => t.id === payment.tenantId);
      if (!tenant) return false;
      
      const unit = units?.find(u => u.id === tenant.unitId);
      
      // Property filter
      if (selectedPropertyId !== "all") {
        if (!unit || unit.propertyId !== selectedPropertyId) return false;
      }
      
      // Unit filter
      if (selectedUnitId !== "all") {
        if (!unit || unit.id !== selectedUnitId) return false;
      }
      
      // Tenant filter
      if (selectedTenantId !== "all") {
        if (tenant.id !== selectedTenantId) return false;
      }
      
      // Status filter
      if (selectedStatus !== "all") {
        if (payment.status !== selectedStatus) return false;
      }
      
      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        const tenantName = `${tenant.firstName} ${tenant.lastName}`.toLowerCase();
        const unitName = unit?.unitNumber?.toLowerCase() || '';
        
        if (!tenantName.includes(searchLower) && !unitName.includes(searchLower)) {
          return false;
        }
      }
      
      return true;
    });
  }, [mockPaymentData, tenants, units, selectedPropertyId, selectedUnitId, selectedTenantId, selectedStatus, searchTerm]);

  // Calculate analytics
  const analytics = useMemo(() => {
    const totalPayments = filteredPayments.length;
    const paidPayments = filteredPayments.filter(p => p.status === 'paid').length;
    const latePayments = filteredPayments.filter(p => p.status === 'late').length;
    const pendingPayments = filteredPayments.filter(p => p.status === 'pending').length;
    const prepaidPayments = filteredPayments.filter(p => p.status === 'prepaid').length;
    
    const totalRevenue = filteredPayments.reduce((sum, p) => sum + p.amount, 0);
    const collectedRevenue = filteredPayments.filter(p => p.status === 'paid' || p.status === 'prepaid').reduce((sum, p) => sum + p.amount, 0);
    const paymentRate = totalPayments > 0 ? Math.round((paidPayments / totalPayments) * 100) : 0;
    
    return {
      totalPayments,
      paidPayments,
      latePayments,
      pendingPayments,
      prepaidPayments,
      totalRevenue,
      collectedRevenue,
      paymentRate,
      outstandingAmount: totalRevenue - collectedRevenue
    };
  }, [filteredPayments]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      paid: { label: 'Paid', variant: 'default' as const, className: 'bg-green-100 text-green-800 hover:bg-green-200' },
      late: { label: 'Late', variant: 'destructive' as const, className: 'bg-red-100 text-red-800 hover:bg-red-200' },
      pending: { label: 'Pending', variant: 'secondary' as const, className: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200' },
      prepaid: { label: 'Prepaid', variant: 'outline' as const, className: 'bg-blue-100 text-blue-800 hover:bg-blue-200' },
    };
    
    return statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
  };

  if (propertiesLoading || unitsLoading || tenantsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Rent Income</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">Track rent payments, manage tenant finances, and monitor payment statuses</p>
        </div>
        <Button 
          onClick={() => setShowRentCollectionModal(true)}
          className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg"
          data-testid="button-add-rent"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Rent
        </Button>
      </div>

      {/* Quick Stats Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        <Card className="bg-gradient-to-br from-blue-500 to-purple-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Payment Rate</p>
                <p className="text-2xl font-bold">{analytics.paymentRate}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-emerald-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Paid</p>
                <p className="text-2xl font-bold">{analytics.paidPayments}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-500 to-pink-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm">Late</p>
                <p className="text-2xl font-bold">{analytics.latePayments}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-500 to-orange-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-100 text-sm">Pending</p>
                <p className="text-2xl font-bold">{analytics.pendingPayments}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-indigo-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-indigo-100 text-sm">Prepaid</p>
                <p className="text-2xl font-bold">{analytics.prepaidPayments}</p>
              </div>
              <DollarSign className="w-8 h-8 text-indigo-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-gray-600 to-gray-700 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Total Revenue</p>
                <p className="text-lg font-bold">{formatCurrency(analytics.totalRevenue)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            {/* Search */}
            <div>
              <label className="text-sm font-medium mb-2 block">Search</label>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                <Input
                  placeholder="Search tenant or unit..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-rent"
                />
              </div>
            </div>

            {/* Property Filter */}
            <div>
              <label className="text-sm font-medium mb-2 block">Property</label>
              <Select value={selectedPropertyId} onValueChange={setSelectedPropertyId}>
                <SelectTrigger data-testid="select-property-filter">
                  <SelectValue placeholder="All Properties" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Properties</SelectItem>
                  {properties?.map((property) => (
                    <SelectItem key={property.id} value={property.id}>
                      {property.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Unit Filter */}
            <div>
              <label className="text-sm font-medium mb-2 block">Unit</label>
              <Select value={selectedUnitId} onValueChange={setSelectedUnitId}>
                <SelectTrigger data-testid="select-unit-filter">
                  <SelectValue placeholder="All Units" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Units</SelectItem>
                  {filteredUnits?.map((unit) => (
                    <SelectItem key={unit.id} value={unit.id}>
                      {unit.unitNumber || `Unit ${unit.id.slice(0, 8)}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Tenant Filter */}
            <div>
              <label className="text-sm font-medium mb-2 block">Tenant</label>
              <Select value={selectedTenantId} onValueChange={setSelectedTenantId}>
                <SelectTrigger data-testid="select-tenant-filter">
                  <SelectValue placeholder="All Tenants" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tenants</SelectItem>
                  {tenants?.map((tenant) => (
                    <SelectItem key={tenant.id} value={tenant.id}>
                      {tenant.firstName} {tenant.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Status Filter */}
            <div>
              <label className="text-sm font-medium mb-2 block">Status</label>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger data-testid="select-status-filter">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="late">Late</SelectItem>
                  <SelectItem value="prepaid">Prepaid</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Reset Filters */}
            <div>
              <label className="text-sm font-medium mb-2 block">&nbsp;</label>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSelectedPropertyId("all");
                  setSelectedUnitId("all");
                  setSelectedTenantId("all");
                  setSelectedStatus("all");
                  setSearchTerm("");
                }}
                className="w-full"
                data-testid="button-reset-filters"
              >
                Reset Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Status List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Payment Status ({filteredPayments.length} tenants)
            </div>
            <div className="text-sm text-muted-foreground">
              Collected: {formatCurrency(analytics.collectedRevenue)} / {formatCurrency(analytics.totalRevenue)}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredPayments.length === 0 ? (
            <div className="text-center py-12">
              <DollarSign className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No Payment Records Found</h3>
              <p className="text-muted-foreground">Try adjusting your filters to see payment data.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPayments.map((payment) => {
                const tenant = tenants?.find(t => t.id === payment.tenantId);
                const unit = tenant?.unitId ? units?.find(u => u.id === tenant.unitId) : null;
                const property = unit?.propertyId ? properties?.find(p => p.id === unit.propertyId) : null;
                const statusConfig = getStatusBadge(payment.status);

                return (
                  <div
                    key={payment.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    data-testid={`payment-item-${payment.id}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center text-white font-semibold">
                        {tenant?.firstName?.[0]}{tenant?.lastName?.[0]}
                      </div>
                      <div>
                        <h4 className="font-semibold">{tenant?.firstName || ''} {tenant?.lastName || ''}</h4>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Building className="w-3 h-3" />
                          <span>{property?.name || 'Unknown Property'}</span>
                          <Home className="w-3 h-3 ml-2" />
                          <span>{unit?.unitNumber || 'N/A'}</span>
                          <Calendar className="w-3 h-3 ml-2" />
                          <span>Due: {payment.dueDate}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="font-semibold">{formatCurrency(payment.amount)}</p>
                        {payment.paymentDate && (
                          <p className="text-sm text-muted-foreground">Paid: {payment.paymentDate}</p>
                        )}
                      </div>
                      <Badge className={statusConfig.className} data-testid={`status-${payment.status}`}>
                        {statusConfig.label}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Rent Collection Modal */}
      <RentCollectionModal 
        open={showRentCollectionModal}
        onOpenChange={setShowRentCollectionModal}
      />
    </div>
  );
}