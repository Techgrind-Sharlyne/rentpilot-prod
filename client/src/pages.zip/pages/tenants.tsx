import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, User, Users, Edit, Home, Building, Phone, Mail, Calendar, DollarSign, Eye, Search } from "lucide-react";
import { useLocation } from "wouter";
import type { TenantWithDetails, UnitWithDetails, PropertyWithDetails } from "@shared/schema";
import { AddTenantModal } from "@/components/modals/add-tenant-modal";
import { AssignUnitModal } from "@/components/modals/assign-unit-modal";

export default function Tenants() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [showAddTenantModal, setShowAddTenantModal] = useState(false);
  const [showAssignUnitModal, setShowAssignUnitModal] = useState(false);
  const [selectedTenantForAssignment, setSelectedTenantForAssignment] = useState<TenantWithDetails | null>(null);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");

  // Create lease mutation for tenants without active leases
  const createLeaseMutation = useMutation({
    mutationFn: async ({ tenantId, unitId }: { tenantId: string; unitId: string }) => {
      const leaseData = {
        tenantId,
        unitId,
        monthlyRent: 20000, // Default rent amount
        securityDeposit: 20000,
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 1 year
        status: "active",
        moveInDate: new Date().toISOString().split('T')[0],
      };
      return await apiRequest("POST", "/api/leases", leaseData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenants"] });
      queryClient.invalidateQueries({ queryKey: ["/api/units"] });
      toast({ title: "Success", description: "Lease created successfully! Tenant can now pay rent." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create lease", variant: "destructive" });
    },
  });

  // Fetch tenants
  const { data: tenants, isLoading: tenantsLoading } = useQuery<TenantWithDetails[]>({
    queryKey: ["/api/tenants"],
  });

  // Fetch units
  const { data: units, isLoading: unitsLoading } = useQuery<UnitWithDetails[]>({
    queryKey: ["/api/units"],
  });

  // Fetch properties
  const { data: properties, isLoading: propertiesLoading } = useQuery<PropertyWithDetails[]>({
    queryKey: ["/api/properties"],
  });

  // Filter tenants based on property, status, and search query
  const filteredTenants = tenants?.filter((tenant: TenantWithDetails) => {
    const matchesProperty = selectedPropertyId === "all" || 
      (tenant.unit?.propertyId === selectedPropertyId);
    const matchesStatus = selectedStatus === "all" || tenant.currentLease?.status === selectedStatus;
    
    // Search functionality - check name, email, phone, unit number, and property name
    const query = searchQuery.toLowerCase();
    const matchesSearch = !query || 
      `${tenant.firstName} ${tenant.lastName}`.toLowerCase().includes(query) ||
      tenant.email?.toLowerCase().includes(query) ||
      tenant.phone?.toLowerCase().includes(query) ||
      tenant.unit?.unitNumber?.toLowerCase().includes(query) ||
      tenant.property?.name?.toLowerCase().includes(query) ||
      tenant.currentLease?.monthlyRent?.toString().includes(query);
    
    return matchesProperty && matchesStatus && matchesSearch;
  }) || [];

  // Calculate analytics
  const tenantAnalytics = {
    totalTenants: tenants?.length || 0,
    activeTenants: tenants?.filter(t => t.currentLease?.status === "active").length || 0,
    pendingTenants: tenants?.filter(t => t.currentLease?.status === "pending").length || 0,
    totalMonthlyRent: tenants?.reduce((sum, t) => sum + (Number(t.currentLease?.monthlyRent) || 0), 0) || 0,
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "pending": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "expired": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "terminated": return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
      default: return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
    }
  };

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
    }).format(amount);

  const formatDate = (dateString: string) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  if (tenantsLoading || unitsLoading || propertiesLoading) {
    return <div className="p-6">Loading tenants...</div>;
  }

  return (
    <div className="p-6 max-w-7xl mx-auto" data-testid="tenants-page">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Tenants Management
          </h1>
          <p className="text-muted-foreground">
            Manage tenant information, leases, and relationships
          </p>
        </div>
        <Button 
          onClick={() => setShowAddTenantModal(true)}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-200"
          data-testid="button-add-tenant"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Tenant
        </Button>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 dark:text-blue-400 text-sm font-medium">Total Tenants</p>
                <p className="text-3xl font-bold text-blue-700 dark:text-blue-300">{tenantAnalytics.totalTenants}</p>
              </div>
              <Users className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 dark:text-green-400 text-sm font-medium">Active Leases</p>
                <p className="text-3xl font-bold text-green-700 dark:text-green-300">{tenantAnalytics.activeTenants}</p>
              </div>
              <Home className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20 border-yellow-200 dark:border-yellow-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-600 dark:text-yellow-400 text-sm font-medium">Pending</p>
                <p className="text-3xl font-bold text-yellow-700 dark:text-yellow-300">{tenantAnalytics.pendingTenants}</p>
              </div>
              <Calendar className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 border-purple-200 dark:border-purple-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-600 dark:text-purple-400 text-sm font-medium">Monthly Revenue</p>
                <p className="text-2xl font-bold text-purple-700 dark:text-purple-300">
                  {formatCurrency(tenantAnalytics.totalMonthlyRent)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search tenants by name, email, phone, unit, or property..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-tenants"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Select value={selectedPropertyId} onValueChange={setSelectedPropertyId}>
              <SelectTrigger data-testid="filter-property">
                <SelectValue placeholder="Filter by property" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Properties</SelectItem>
                {properties?.map((property) => (
                  <SelectItem key={property.id} value={property.id}>
                    {property.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger data-testid="filter-status">
                <SelectValue placeholder="Filter by lease status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
                <SelectItem value="terminated">Terminated</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center space-x-2">
            {(selectedPropertyId !== "all" || selectedStatus !== "all" || searchQuery) && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSelectedPropertyId("all");
                  setSelectedStatus("all");
                  setSearchQuery("");
                }}
                data-testid="clear-filters"
              >
                Clear All
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Tenants Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTenants.map((tenant: TenantWithDetails) => (
          <Card key={tenant.id} className="group hover:shadow-lg hover:scale-[1.02] transition-all duration-200 border-l-4 border-l-green-500" data-testid={`tenant-card-${tenant.id}`}>
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg leading-tight group-hover:text-green-600 transition-colors">
                      {tenant.firstName} {tenant.lastName}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      {tenant.unit ? 
                        `Unit ${tenant.unit.unitNumber || 'N/A'} - ${properties?.find(p => p.id === tenant.unit?.propertyId)?.name || 'Unknown Property'}` :
                        'No Unit Assigned'
                      }
                    </p>
                  </div>
                  <Badge className={getStatusColor(tenant.currentLease?.status || "pending")} variant="secondary">
                    {tenant.currentLease?.status || "pending"}
                  </Badge>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{tenant.phone}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground truncate">{tenant.email}</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-green-50 dark:bg-green-900/20 p-2 rounded-lg">
                    <div className="text-green-600 dark:text-green-400 font-medium">Monthly Rent</div>
                    <div className="font-bold text-green-700 dark:text-green-300">
                      {formatCurrency(Number(tenant.currentLease?.monthlyRent) || 0)}
                    </div>
                  </div>
                  
                  <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg">
                    <div className="text-blue-600 dark:text-blue-400 font-medium">Lease Start</div>
                    <div className="font-bold text-blue-700 dark:text-blue-300">
                      {formatDate(tenant.currentLease?.startDate ? tenant.currentLease.startDate.toString() : "")}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="text-xs text-muted-foreground">
                    Move-in: {formatDate(tenant.currentLease?.moveInDate ? tenant.currentLease.moveInDate.toString() : "")}
                  </div>
                  <div className="flex items-center space-x-1">
                    {!tenant.currentLease && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="h-6 px-2 text-xs bg-orange-50 hover:bg-orange-100 text-orange-600 border-orange-200"
                        onClick={() => {
                          setSelectedTenantForAssignment(tenant);
                          setShowAssignUnitModal(true);
                        }}
                        data-testid={`button-assign-unit-${tenant.id}`}
                        disabled={createLeaseMutation.isPending}
                      >
                        <Home className="w-3 h-3 mr-1" />
                        Assign Unit
                      </Button>
                    )}
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className="h-6 w-6 p-0 hover:bg-green-100 hover:text-green-600"
                      onClick={() => {
                        // TODO: Open edit tenant modal
                        console.log('Edit tenant:', tenant.id);
                      }}
                      data-testid={`button-edit-tenant-${tenant.id}`}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className="h-6 w-6 p-0 hover:bg-blue-100 hover:text-blue-600"
                      onClick={() => {
                        // TODO: Open tenant details modal
                        console.log('View tenant:', tenant.id);
                      }}
                      data-testid={`button-view-tenant-${tenant.id}`}
                    >
                      <Eye className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTenants.length === 0 && (
        <div className="text-center py-12">
          <User className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No Tenants Found</h3>
          <p className="text-muted-foreground mb-4">
            {selectedPropertyId !== "all" || selectedStatus !== "all" 
              ? "Try adjusting your filters or add a new tenant."
              : "Get started by adding your first tenant."
            }
          </p>
          <Button onClick={() => setShowAddTenantModal(true)} className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Tenant
          </Button>
        </div>
      )}

      {/* Add Tenant Modal */}
      <AddTenantModal
        open={showAddTenantModal}
        onClose={() => setShowAddTenantModal(false)}
      />

      {/* Assign Unit Modal */}
      <AssignUnitModal
        open={showAssignUnitModal}
        onOpenChange={setShowAssignUnitModal}
        units={units || []}
        properties={properties || []}
        tenantName={selectedTenantForAssignment ? `${selectedTenantForAssignment.firstName} ${selectedTenantForAssignment.lastName}` : ""}
        onAssignUnit={(unitId) => {
          if (selectedTenantForAssignment) {
            createLeaseMutation.mutate({ tenantId: selectedTenantForAssignment.id, unitId });
            setShowAssignUnitModal(false);
            setSelectedTenantForAssignment(null);
          }
        }}
        isLoading={createLeaseMutation.isPending}
      />
    </div>
  );
}