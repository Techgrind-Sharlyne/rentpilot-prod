import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Plus, Home, Building, User, Edit, DollarSign, 
  Bed, Bath, Square, X, Settings, Trash2, Search 
} from "lucide-react";
import type { PropertyWithDetails, UnitWithDetails } from "@shared/schema";
import { useLocation } from "wouter";
import { AddUnitModal } from "@/components/modals/add-unit-modal";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function UnitsPage() {
  const [location, setLocation] = useLocation();
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddUnitModal, setShowAddUnitModal] = useState(false);
  const [showAddTenantModal, setShowAddTenantModal] = useState(false);
  const [editingUnit, setEditingUnit] = useState<UnitWithDetails | null>(null);
  
  const { toast } = useToast();

  // Delete unit mutation
  const deleteUnitMutation = useMutation({
    mutationFn: async (unitId: string) => {
      return await apiRequest("DELETE", `/api/units/${unitId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/units"] });
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      toast({ title: "Success", description: "Unit deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete unit", variant: "destructive" });
    },
  });

  // Handle property filtering from URL parameter
  useEffect(() => {
    if (location && location.includes('?')) {
      const urlParams = new URLSearchParams(location.split('?')[1]);
      const propertyIdFromUrl = urlParams.get('propertyId');
      
      if (propertyIdFromUrl && propertyIdFromUrl !== selectedPropertyId) {
        setSelectedPropertyId(propertyIdFromUrl);
      }
    }
  }, [location, selectedPropertyId]);

  // Fetch properties
  const { data: properties, isLoading: propertiesLoading } = useQuery<PropertyWithDetails[]>({
    queryKey: ["/api/properties"],
  });

  // Fetch units  
  const { data: units, isLoading: unitsLoading } = useQuery<UnitWithDetails[]>({
    queryKey: ["/api/units"],
  });

  // Filter units based on property, status, and search query
  const filteredUnits = useMemo(() => {
    if (!units) return [];
    
    return units.filter((unit: UnitWithDetails) => {
      const matchesProperty = selectedPropertyId === "all" || unit.propertyId === selectedPropertyId;
      const matchesStatus = selectedStatus === "all" || unit.status === selectedStatus;
      
      // Search functionality - check unit number, property name, tenant name, and monthly rent
      const query = searchQuery.toLowerCase();
      const matchesSearch = !query || 
        unit.unitNumber.toLowerCase().includes(query) ||
        unit.property?.name?.toLowerCase().includes(query) ||
        unit.tenant?.fullName?.toLowerCase().includes(query) ||
        unit.tenant?.email?.toLowerCase().includes(query) ||
        unit.monthlyRent?.toString().includes(query);
      
      return matchesProperty && matchesStatus && matchesSearch;
    });
  }, [units, selectedPropertyId, selectedStatus, searchQuery]);

  // Calculate analytics
  const unitAnalytics = useMemo(() => {
    if (!units) {
      return {
        totalUnits: 0,
        occupiedUnits: 0,
        vacantUnits: 0,
        totalRevenue: 0,
        occupancyRate: "0%"
      };
    }

    const totalUnits = units.length;
    const occupiedUnits = units.filter((u: UnitWithDetails) => u.status === "occupied").length;
    const vacantUnits = units.filter((u: UnitWithDetails) => u.status === "vacant").length;
    const totalRevenue = units.reduce((sum: number, u: UnitWithDetails) => sum + (Number(u.monthlyRent) || 0), 0);
    const occupancyRate = totalUnits > 0 ? Math.round((occupiedUnits / totalUnits) * 100) : 0;

    return {
      totalUnits,
      occupiedUnits,
      vacantUnits,
      totalRevenue,
      occupancyRate: `${occupancyRate}%`
    };
  }, [units]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "vacant": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "occupied": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "maintenance": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "reserved": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "under_renovation": return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    }
  };

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
    }).format(amount);

  if (propertiesLoading || unitsLoading) {
    return <div className="p-6">Loading units...</div>;
  }

  return (
    <div className="p-6 max-w-7xl mx-auto" data-testid="units-page">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Units Management
          </h1>
          <p className="text-muted-foreground">
            {units?.length || 0} units across all properties
          </p>
        </div>
        <Button 
          onClick={() => setShowAddUnitModal(true)} 
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-200"
          data-testid="button-add-unit"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Unit
        </Button>
      </div>

      {/* Analytics Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 dark:text-blue-400 text-sm font-medium">Total Units</p>
                <p className="text-3xl font-bold text-blue-700 dark:text-blue-300">{unitAnalytics.totalUnits}</p>
              </div>
              <Building className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 dark:text-green-400 text-sm font-medium">Occupied</p>
                <p className="text-3xl font-bold text-green-700 dark:text-green-300">{unitAnalytics.occupiedUnits}</p>
              </div>
              <Home className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20 border-yellow-200 dark:border-yellow-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-600 dark:text-yellow-400 text-sm font-medium">Vacant</p>
                <p className="text-3xl font-bold text-yellow-700 dark:text-yellow-300">{unitAnalytics.vacantUnits}</p>
              </div>
              <User className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 border-purple-200 dark:border-purple-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-600 dark:text-purple-400 text-sm font-medium">Total Revenue</p>
                <p className="text-2xl font-bold text-purple-700 dark:text-purple-300">
                  {formatCurrency(unitAnalytics.totalRevenue)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search units by number, property, tenant, or rent amount..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-units"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Select value={selectedPropertyId} onValueChange={setSelectedPropertyId}>
              <SelectTrigger data-testid="filter-property">
                <SelectValue placeholder="Filter by property" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Properties</SelectItem>
                {properties?.map((property) => (
                  <SelectItem key={property.id} value={property.id}>
                    {property.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger data-testid="filter-status">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="vacant">Vacant</SelectItem>
                <SelectItem value="occupied">Occupied</SelectItem>
                <SelectItem value="maintenance">Maintenance</SelectItem>
                <SelectItem value="reserved">Reserved</SelectItem>
                <SelectItem value="under_renovation">Under Renovation</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            {(selectedPropertyId !== "all" || selectedStatus !== "all" || searchQuery) && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSelectedPropertyId("all");
                  setSelectedStatus("all");
                  setSearchQuery("");
                }}
                data-testid="clear-filters"
              >
                <X className="w-4 h-4 mr-1" />
                Clear All
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Units Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredUnits?.map((unit: UnitWithDetails) => (
          <Card key={unit.id} className="group hover:shadow-lg hover:scale-[1.02] transition-all duration-200 border-l-4 border-l-blue-500" data-testid={`unit-card-${unit.id}`}>
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg leading-tight group-hover:text-blue-600 transition-colors">
                      Unit {unit.unitNumber}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      {properties?.find(p => p.id === unit.propertyId)?.name || 'Unknown Property'}
                    </p>
                  </div>
                  <Badge className={getStatusColor(unit.status || "vacant")} variant="secondary">
                    {(unit.status || "vacant").replace('_', ' ')}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg">
                    <div className="text-blue-600 dark:text-blue-400 font-medium">Rent</div>
                    <div className="font-bold text-blue-700 dark:text-blue-300">
                      {formatCurrency(Number(unit.monthlyRent) || 0)}
                    </div>
                  </div>
                  
                  <div className="bg-purple-50 dark:bg-purple-900/20 p-2 rounded-lg">
                    <div className="text-purple-600 dark:text-purple-400 font-medium">Deposit</div>
                    <div className="font-bold text-purple-700 dark:text-purple-300">
                      {formatCurrency(Number(unit.securityDeposit) || 0)}
                    </div>
                  </div>
                </div>

                {(unit.bedrooms || unit.bathrooms || unit.squareFeet) && (
                  <div className="flex items-center justify-center space-x-4 pt-2 border-t">
                    {unit.bedrooms && (
                      <div className="flex items-center space-x-1 text-xs">
                        <Bed className="w-3 h-3 text-muted-foreground" />
                        <span>{unit.bedrooms} bed</span>
                      </div>
                    )}
                    {unit.bathrooms && (
                      <div className="flex items-center space-x-1 text-xs">
                        <Bath className="w-3 h-3 text-muted-foreground" />
                        <span>{unit.bathrooms} bath</span>
                      </div>
                    )}
                    {unit.squareFeet && (
                      <div className="flex items-center space-x-1 text-xs">
                        <Square className="w-3 h-3 text-muted-foreground" />
                        <span>{unit.squareFeet} ft²</span>
                      </div>
                    )}
                  </div>
                )}

                <div className="flex items-center justify-between pt-2">
                  {unit.tenantName && (
                    <div className="flex items-center space-x-1">
                      <User className="w-3 h-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground truncate">
                        {unit.tenantName}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center space-x-1">
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className="h-6 w-6 p-0 hover:bg-green-100 hover:text-green-600"
                      onClick={() => setShowAddTenantModal(true)}
                      data-testid={`button-manage-unit-${unit.id}`}
                    >
                      <Settings className="w-3 h-3" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className="h-6 w-6 p-0 hover:bg-blue-100 hover:text-blue-600"
                      onClick={() => {
                        setEditingUnit(unit);
                        setShowAddUnitModal(true);
                      }}
                      data-testid={`button-edit-unit-${unit.id}`}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      className="h-6 w-6 p-0 hover:bg-red-100 hover:text-red-600"
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete Unit ${unit.unitNumber}? This action cannot be undone.`)) {
                          deleteUnitMutation.mutate(unit.id);
                        }
                      }}
                      data-testid={`button-delete-unit-${unit.id}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredUnits && filteredUnits.length === 0 && (
        <div className="text-center py-12">
          <Home className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No Units Found</h3>
          <p className="text-muted-foreground mb-4">
            {selectedPropertyId !== "all" || selectedStatus !== "all" 
              ? "Try adjusting your filters or add a new unit."
              : "Get started by adding your first unit."
            }
          </p>
          <Button onClick={() => setShowAddUnitModal(true)} className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Unit
          </Button>
        </div>
      )}

      {/* Add Unit Modal */}
      <AddUnitModal
        open={showAddUnitModal}
        onClose={() => {
          setShowAddUnitModal(false);
          setEditingUnit(null);
        }}
        preSelectedPropertyId={selectedPropertyId !== "all" ? selectedPropertyId : undefined}
        editUnit={editingUnit}
      />
    </div>
  );
}